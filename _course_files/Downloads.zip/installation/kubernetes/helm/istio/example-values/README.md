# Example Values

These files provide various example values for different Istio setups.

To use them, [read the docs](https://istio.io/docs/setup/kubernetes/helm-install/) and add the flag `--values example-file.yaml`.
